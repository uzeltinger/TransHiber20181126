package com.cfp403.controladores;

import com.cfp403.helpers.HibernateUtil;
import com.cfp403.modelos.Camion;
import java.util.List;
import javax.persistence.criteria.CriteriaQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Inicio {
    public static void main(String[] args) {
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        Session session = null;
        
        try {
            session = HibernateUtil.getSessionFactory().openSession();
         //transaction = session.beginTransaction();  
            session.beginTransaction(); 
            
            /*  save
            Camion c1 = new Camion();    
            c1.setPatente("AAA346");
            c1.setMarca("Fiat");
            c1.setModelo("619");
            System.out.println("c1: " + c1.toString());
            session.save(c1);
            */
            
            /*  saveOrUpdate
            Camion c2 = new Camion();
            c2.setId(2);   
            c2.setPatente("AAA341");
            c2.setMarca("Fiato");
            c2.setModelo("333");
            session.saveOrUpdate(c2);
            */
            
            /*  get */
            Camion camion = session.get(Camion.class, 4);
            System.out.println("camion obtenido: " + camion.toString());
            
            /*  Criteria list    */
            CriteriaQuery<Camion> query = session.getCriteriaBuilder()
                    .createQuery(Camion.class);
            query.select(query.from(Camion.class));
            List<Camion> camiones = session.createQuery(query).list();
            System.out.println("camiones totales: " + camiones.size());
            System.out.println("camiones : " + camiones.toString());
            
            
            
            // Check database version
            /*
            String sql = "select * from camion limit 1";
            Camion result = (Camion) session.createNativeQuery(sql).getSingleResult();
            System.out.println("resultado: " + result.toString());
*/
  
    
            
            
            session.getTransaction().commit(); 
            session.close(); 
            HibernateUtil.shutdown();
            
        } catch (Exception e) {
             e.printStackTrace();
            } finally {
                if (session != null) {
                session.close();
            }
         }

    }
}
