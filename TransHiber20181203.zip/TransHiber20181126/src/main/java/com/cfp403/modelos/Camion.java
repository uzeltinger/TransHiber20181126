package com.cfp403.modelos;

public class Camion {
    private int id;
    private String patente;
    private String marca;
    private String modelo;
    //private String tipo;
    //private String seguro;
    //private Boolean propio;
    //private Empleado chofer;

    public Camion() {
    }

    public Camion(String patente, String marca, String modelo) {
        this.patente = patente;
        this.marca = marca;
        this.modelo = modelo;        
    }

    public String getPatente() {
        return patente;
    }

    public void setPatente(String patente) {
        this.patente = patente;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
  
    @Override
    public String toString() {
        return this.patente;
    }    
}