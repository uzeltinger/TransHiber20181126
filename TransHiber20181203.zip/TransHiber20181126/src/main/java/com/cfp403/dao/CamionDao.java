/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cfp403.dao;

import com.cfp403.helpers.HibernateUtil;
import com.cfp403.modelos.Camion;
import java.util.List;
import javax.persistence.criteria.CriteriaQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author Diseño gráfico
 */
public class CamionDao {
    SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
    Session session = null;
    
    public List getCamiones(){
    try {
            session = HibernateUtil.getSessionFactory().openSession(); 
            session.beginTransaction();
            CriteriaQuery<Camion> query = session.getCriteriaBuilder()
                    .createQuery(Camion.class);
            query.select(query.from(Camion.class));
            List<Camion> camiones = session.createQuery(query).list();
            System.out.println("camiones totales: " + camiones.size());
            System.out.println("camiones : " + camiones.toString());
            session.getTransaction().commit(); 
            session.close(); 
            HibernateUtil.shutdown();
            return camiones;
            
        } catch (Exception e) {
             e.printStackTrace();
            } finally {
                if (session != null) {
                session.close();
            }
        }
    return null;
    }
    
    public Camion guardarCamion(Camion camion){ 
        try{
        session = HibernateUtil.getSessionFactory().openSession();
         //transaction = session.beginTransaction();  
        session.beginTransaction(); 
        session.saveOrUpdate(camion);
        session.getTransaction().commit(); 
        } catch (Exception e) {
             e.printStackTrace();
            } finally {
                if (session != null) {
                session.close();
            }
        }        
        return camion;
    }
}
